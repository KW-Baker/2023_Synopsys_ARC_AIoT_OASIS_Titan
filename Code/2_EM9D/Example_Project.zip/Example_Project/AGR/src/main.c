/***************************************************************************************************/
// FILE NAME:    main.cpp
// VERSION:      1.0 
// DATE:         July 1, 2023
// AUTHOR:       KUAN-WEI, CHEN, NYCU IEE
// CODE TYPE:    CPP
// DESCRIPTION:  2023 Synopsys ARC AIoT / Analog Gauge Reader
// MODIFICATION: 
// Date          Description
// 07/01       
/***************************************************************************************************/
#include "main.h"

#include "tflitemicro_algo.h"
#include "model_settings.h"

#include "synopsys_sdk_camera_drv.h"
// #include "hx_drv_iic_m.h"
// #include "synopsys_i2c_oled1306.h"

DEV_UART * uart0_ptr;

char uart_buf[uart_buf_size] = {0};

extern uint32_t g_wdma2_baseaddr;

int8_t test_img [kNumRows * kNumCols] = {0};
uint8_t output_img [kNumRows * kNumCols] = {0};
uint8_t output_height = kNumRows;
uint8_t output_width = kNumCols;

uint8_t * img_ptr;
uint32_t img_width = 640;
uint32_t img_height = 480;

int main(void)
{
    //UART 0 is already initialized with 115200bps
    // uart0 init
    uart0_ptr = hx_drv_uart_get_dev(USE_SS_UART_0);

    // Camera
    synopsys_camera_init();
    
    // TFLM model
    tflitemicro_algo_init();


    sprintf(uart_buf, "**==========================================================**\r\n"); uart0_ptr->uart_write(uart_buf, strlen(uart_buf)); board_delay_ms(50);
    sprintf(uart_buf, "**       .88888.    .d888888  .d88888b   dP  .d88888b       **\r\n"); uart0_ptr->uart_write(uart_buf, strlen(uart_buf)); board_delay_ms(50);
    sprintf(uart_buf, "**      d8a   a8b  d8a    88  88a    'a  88  88a    ''      **\r\n"); uart0_ptr->uart_write(uart_buf, strlen(uart_buf)); board_delay_ms(50);
    sprintf(uart_buf, "**      88     88  88aaaaa88  'Y88888b.  88  `Y88888b.      **\r\n"); uart0_ptr->uart_write(uart_buf, strlen(uart_buf)); board_delay_ms(50);
    sprintf(uart_buf, "**      88     88  88     88        `8b  88        `8b      **\r\n"); uart0_ptr->uart_write(uart_buf, strlen(uart_buf)); board_delay_ms(50);
    sprintf(uart_buf, "**      Y8.   .8P  88     88  d8'   .8P  88  d8'   .8P      **\r\n"); uart0_ptr->uart_write(uart_buf, strlen(uart_buf)); board_delay_ms(50);
    sprintf(uart_buf, "**       `8888P'   88     88   Y88888P   dP   Y88888P       **\r\n"); uart0_ptr->uart_write(uart_buf, strlen(uart_buf)); board_delay_ms(50);
    sprintf(uart_buf, "**                                                          **\r\n"); uart0_ptr->uart_write(uart_buf, strlen(uart_buf)); board_delay_ms(50);
    sprintf(uart_buf, "**    d888888b  d8888b  d888888b  .d888888   .d88    8d     **\r\n"); uart0_ptr->uart_write(uart_buf, strlen(uart_buf)); board_delay_ms(50);
    sprintf(uart_buf, "**       88       88       88     d8a    88  d8 P8   8d     **\r\n"); uart0_ptr->uart_write(uart_buf, strlen(uart_buf)); board_delay_ms(50);
    sprintf(uart_buf, "**       88       88       88     88aaaaa88  d8  P8  8d     **\r\n"); uart0_ptr->uart_write(uart_buf, strlen(uart_buf)); board_delay_ms(50);
    sprintf(uart_buf, "**       88       88       88     88     88  d8   P8 8d     **\r\n"); uart0_ptr->uart_write(uart_buf, strlen(uart_buf)); board_delay_ms(50);
    sprintf(uart_buf, "**       88       88       88     88     88  d8    P88d     **\r\n"); uart0_ptr->uart_write(uart_buf, strlen(uart_buf)); board_delay_ms(50);
    sprintf(uart_buf, "**       88     d8888b     88     88     88  d8     P8d     **\r\n"); uart0_ptr->uart_write(uart_buf, strlen(uart_buf)); board_delay_ms(50);
    sprintf(uart_buf, "**==========================================================**\r\n"); uart0_ptr->uart_write(uart_buf, strlen(uart_buf)); board_delay_ms(50);
    sprintf(uart_buf, " [Inference Start...] \r\n"); uart0_ptr->uart_write(uart_buf, strlen(uart_buf)); board_delay_ms(50);

    
    while(1)
    {
        synopsys_camera_start_capture();
        board_delay_ms(10); // 100

        
        img_ptr = (uint8_t *) g_wdma2_baseaddr;

        synopsys_camera_down_scaling(img_ptr, img_width, img_height, &output_img[0], output_width, output_height);
     
        for(uint32_t pixel_index = 0; pixel_index < kImageSize; pixel_index++)
            test_img[pixel_index] = output_img[pixel_index] - 128;

        int32_t test_result = tflitemicro_algo_run(&test_img[0]);
        // sprintf(uart_buf, "Estimate degree: %2d ~ %2d\r\n", test_result*6, (test_result+1)*6);
        sprintf(uart_buf, "%2d\r\n", test_result);
        uart0_ptr->uart_write(uart_buf, strlen(uart_buf));
            board_delay_ms(10);


        //board_delay_ms(10); // 1000
    }

	return 0;
}

